const StoreItem = {
    emailUserLogged : 'emailUserLogged',
    dataUserSignIn : 'dataUserSignIn'
}

export default StoreItem