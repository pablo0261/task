const PATHROUTES = {
    landing: "/",
    logIn: "/logIn",
    signIn: "/signIn",
    home: "/home",
}

export default PATHROUTES