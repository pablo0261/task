import { Formik, Form } from "formik";
import { Link } from "react-router-dom";
import FormikInput from "../../components/formik/formikInput.jsx";
import  loginValidationSchema  from "./loginValidation.js";
import helpers from '../../helpers/routesFront.js'

function LogIn() {
  const initialValues = {
    email: "",
    password: "",
  };

  return (
    <div className="bg-gray-200 min-h-screen flex items-center justify-center">
      <div className="max-w-md w-full py-8 px-4">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">MyTask</h1>
          <h2 className="text-xl text-gray-600">“Tu agenda, tu <span className="font-bold">control</span> total”</h2>
          <h3 className="text-sm text-gray-600">Simplificando la gestión de tareas.</h3>
        </div>
        <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
          <h2 className="text-xl font-bold mb-4">Iniciar Sesión</h2>
          <Formik
            initialValues={initialValues}
            onSubmit={(values) => console.log(values)}
            validationSchema={loginValidationSchema}
          >
            {() => (
              <Form>
                <FormikInput name="email" label="Email" placeholder="example@mail.com" />
                <FormikInput name="password" label="Contraseña" securetextentry="true" />
                <button type="submit" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full mt-4 w-full">
                  Ingresar
                </button>
              </Form>
            )}
          </Formik>
          <div className="my-4 flex items-center justify-center">
            <div className="border-b border-gray-400 w-full"></div>
            <div className="mx-2 text-gray-400">o</div>
            <div className="border-b border-gray-400 w-full"></div>
          </div>
          <div className="flex justify-center space-x-4">
            <div className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-full cursor-pointer">Google</div>
            <div className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full cursor-pointer">Facebook</div>
          </div>
        </div>
        <div className="text-center">
          <p className="text-sm text-gray-600">
            ¿No tienes una cuenta? <Link to={helpers.signIn} className="text-blue-500 hover:underline">Registrate</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default LogIn;
